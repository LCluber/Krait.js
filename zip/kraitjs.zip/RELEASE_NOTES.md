
Version 0.1.1 (October 28th 2017)
-----------------------------
 * The 'addInput()' method of the 'Keyboard' class can now receive an ASCII code or a string as parameter. The string will then be converted as a valid ASCII code.

Version 0.1.0 (August 25th 2017)
-----------------------------
 * initial version
